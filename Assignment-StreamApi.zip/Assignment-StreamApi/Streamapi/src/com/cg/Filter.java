package com.cg;

import java.util.function.Predicate;

public class Filter {
	
	public static Predicate<String> nameStartingWithPrefix(String pf){
		return name->name.startsWith(pf);
	}

}
