package com.cg;

import java.util.List;
import java.util.ArrayList;
import java.util.function.Function;

public class Mapper {
	
	public static Function<String,  CharactersCount> getDistinctCharactersCount(){
		return d->{
			   List<Characters> distinct = new ArrayList<Characters>();
		               for( int j = 0; j < d.length(); j++) {
		                     if( !distinct.contains( d.charAt( j ) ) ) {
		                         distinct.add( d.charAt( j ) );
		                     }
		               }
                           Integer distinctcount = distinct.size();
		           return new CharactersCount(d, distinctcount );
			  };
		
	}
}