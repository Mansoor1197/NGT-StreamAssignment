package com.cg;

import java.util.Arrays;
import java.util.List;

public class User {

	public static void main(String[] args) {
		
		Filter f = new Filter();
		Mapper m = new Mapper();
		List<String> listofnames = Arrays.asList("aaryanna", "aayanna", "airianna", "alassandra", "allanna", "allannah",
		                                "allessandra", "allianna", "allyanna", "anastaisa", "anastashia", "anastasia", "annabella", "annabelle",
		                                "annebelle");
		 listofnames.stream()
		.filter(f.nameStartingWithPrefix("aa"))
		.map(m.getDistinctCharactersCount())
		.forEach(System.out::println);
		
		
		

	}

}
